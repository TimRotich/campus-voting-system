<footer class="main-footer">
    <div class="container">
      
  
      <strong>&copy;2020 Group5 CVS Project.&nbsp; &nbsp; <b>All rights reserved</b>
     <a></a></strong>
    </div>
    <!-- /.container -->
</footer>